import React from 'react'
import Div from '../Div'
import Slider from "react-slick";


export default function LogoList({partner_data}) {
    const logos = partner_data.logos
    var settings = {
        dots: true,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 2000,
        speed: 500,
        slidesToShow: 4,
        responsive: [
          {
            breakpoint: 1024,
            settings: {
              slidesToShow: 3,
            }
          },
          {
            breakpoint: 600,
            settings: {
              slidesToShow: 2,
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
            }
          }
        ]
      };
  return (
    <Slider {...settings} className='cs_partners_slider'>

      {logos.map((partnerLogo, index)=><div className="cs-partner_logo" key={index}><img src={partnerLogo} alt="Partner" /></div>)}
    </Slider>
  )
}
