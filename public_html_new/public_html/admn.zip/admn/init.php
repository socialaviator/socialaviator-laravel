<?php
session_start();
require_once 'config/db.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}
?>
