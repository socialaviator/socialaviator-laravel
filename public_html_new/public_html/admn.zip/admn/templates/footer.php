</div> <!-- Closing container -->
<footer>
    <p>&copy; <?php echo date('Y'); ?> Admin Panel. All rights reserved.</p>
</footer>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
