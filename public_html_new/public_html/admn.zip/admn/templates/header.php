<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/styles.css" rel="stylesheet">
    <title>Admin Panel</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Admin Panel</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="modules/streams/manage_streams.php">Streams</a></li>
                <li class="nav-item"><a class="nav-link" href="modules/courses/manage_courses.php">Courses</a></li>
                <li class="nav-item"><a class="nav-link" href="modules/colleges/manage_colleges.php">Colleges</a></li>
                <li class="nav-item"><a class="nav-link" href="modules/banners/manage_banners.php">Banners</a></li>
                <li class="nav-item"><a href="/admn/logout.php" class="btn btn-danger">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container mt-4">
