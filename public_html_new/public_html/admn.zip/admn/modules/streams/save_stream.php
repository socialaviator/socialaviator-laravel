<?php
require_once '../../init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    
    // File upload handling
    $image = $_FILES['image'];
    $target_dir = "../../assets/images/";
    $target_file = $target_dir . basename($image['name']);

    if (move_uploaded_file($image['tmp_name'], $target_file)) {
        $image_path = "assets/images/" . basename($image['name']);
    } else {
        die("Error uploading file");
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO streams (title, image, description) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $image_path, $description);
    if ($stmt->execute()) {
        header('Location: manage_streams.php');
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
