<?php
//error_reporting(0);
// Assuming you already have a connection to your database
include('../../init.php');

// Fetch existing streams from the database where is_active = 1 (only active streams)
$sql = "SELECT * FROM streams WHERE is_active = 1"; // Only show active streams
$result = mysqli_query($conn, $sql);

// Handle adding, editing, and deleting streams
if (isset($_POST['add_stream'])) {
    $title = $_POST['title'];
    $image = $_POST['image']; // Assume you handle image upload via another method
    $description = $_POST['description'];

    // Insert new stream into the database
    $insert_sql = "INSERT INTO streams (title, image, description, is_active) VALUES ('$title', '$image', '$description', 1)";
    mysqli_query($conn, $insert_sql);
    header('Location: manage_streams.php'); // Redirect after adding
}

if (isset($_GET['delete'])) {
    $stream_id = $_GET['delete'];
    $delete_sql = "UPDATE streams SET is_active = 0 WHERE id = $stream_id"; // Soft delete
    mysqli_query($conn, $delete_sql);
    header('Location: manage_streams.php'); // Redirect after deleting
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Streams</title>
    <!-- Link to Bootstrap CSS -->
    <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/styles.css">
</head>
<body>
    <!-- Navbar or header -->
    <?php include('../../templates/header.php'); ?>

    <div class="container mt-5">
        <h2>Manage Streams</h2>
        <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addStreamModal">Add Stream</button>

        <!-- Table for managing streams -->
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td><img src="images/<?php echo $row['image']; ?>" alt="<?php echo $row['title']; ?>" style="width: 50px;"></td>
                        <td><?php echo $row['description']; ?></td>
                        <td>
                            <a href="edit_stream.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="manage_streams.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal for adding a new stream -->
    <div class="modal fade" id="addStreamModal" tabindex="-1" aria-labelledby="addStreamModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addStreamModalLabel">Add Stream</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="manage_streams.php" method="POST">
                        <div class="mb-3">
                            <label for="title" class="form-label">Stream Title</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Image</label>
                            <input type="text" class="form-control" id="image" name="image" placeholder="image.jpg" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                        </div>
                        <button type="submit" name="add_stream" class="btn btn-primary">Add Stream</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include('../../templates/footer.php'); ?>

    <!-- Bootstrap JS (Optional: for modal functionality) -->
    <script src="../../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
