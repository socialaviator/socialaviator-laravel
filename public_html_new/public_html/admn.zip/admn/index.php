<?php
require_once 'init.php';
include 'templates/header.php';
?>

<div class="row">
    <div class="col-md-12 text-center">
        <h1>Welcome, <?= $_SESSION['username'] ?>!</h1>
        <p>Select a module to manage:</p>
    </div>
    </div>

    <div class="row mt-4">
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h5 class="card-title">Streams</h5>
                <a href="modules/streams/manage_streams.php" class="btn btn-primary">Manage</a>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h5 class="card-title">Courses</h5>
                <a href="modules/courses/manage_courses.php" class="btn btn-primary">Manage</a>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h5 class="card-title">Colleges</h5>
                <a href="modules/colleges/manage_colleges.php" class="btn btn-primary">Manage</a>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h5 class="card-title">Banners</h5>
                <a href="modules/banners/manage_banners.php" class="btn btn-primary">Manage</a>
            </div>
        </div>
    </div>
</div>

<?php include 'templates/footer.php'; ?>
