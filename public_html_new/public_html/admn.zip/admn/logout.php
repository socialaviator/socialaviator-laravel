<?php
session_start();
session_unset();
session_destroy();

// Redirect to login page
header("Location: /admn/login.php"); // Update the path to your login page
exit;
?>
